<?php require_once 'includes/header.php' ?>
<h1> BNT JUS.VIBE! </h1>
<h1 class= "text-center"> Regestration for IT Conference </h1>
<form>

<label for="exampleFirstName">First Name</label>
    <input type="FirstName" class="form-control" id="exampleInputFirstName" aria-describedby="emailHelp">

    <label for="exampleLastName">Last Name</label>
    <input type="LastName" class="form-control" id="exampleInputLastName" aria-describedby="emailHelp">
    <form action="/action_page.php">
  <label for="Date">Date:</label>
  <input type="date" id="date" name="date">
<form action="/action_page.php">
<label for="Specialty">Specialty</label>
    <input type="Specialty" class="form-control" id="exampleInputSpecialty" aria-describedby="emailHelp"> 
    <input type="checkbox" class="form-check input" id="examplecheck1" aria-describedby="emailHelp">
    <label class= "form-check-label" for="examplecheck1" > DATABASE ADMIN </label>

    <input type="checkbox" class="form-check input" id="examplecheck1" aria-describedby="emailHelp">
    <label class= "form-check-label" for="examplecheck1" > SOFTWARE DEVELOPER </label>
    <input type="checkbox" class="form-check input" id="examplecheck1" aria-describedby="emailHelp">
    <label class= "form-check-label" for="examplecheck1" > WEB ADMINISTRATOR </label>

       
  <div class="form-group">
    <label for="exampleInputContact Number">Contact Number</label>
    <input type="Contact Number" class="form-control" id="exampleInputContact Number" aria-describedby="Contact Number">
   
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary" style= "height: 50px; width: 2000px">Submit</button></label>

</form>
<?php require_once 'includes/footer.php' ?>
